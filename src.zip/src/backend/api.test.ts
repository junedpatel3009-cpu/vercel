﻿import { describe, it, expect, beforeAll, afterAll, beforeEach } from "vitest";
import Database from "better-sqlite3";
import { createHash, createHmac } from "node:crypto";
import {
  getTestDb,
  cleanTestDb,
  createTestUser,
  createTestJob,
  createTestWallet,
} from "./test-helper";
import { hashPassword, verifyPassword } from "@/lib/password.server";
import { issueAccessToken, readAccessToken, tokenHash, opaqueToken } from "./auth.server";
import { ApiError, json, errorResponse, body } from "./http.server";

// ======== Backend Unit Tests ========

describe("Auth Module", () => {
  let db: ReturnType<typeof Database>;

  beforeAll(() => {
    db = getTestDb();
  });

  afterAll(() => {
    cleanTestDb();
  });

  describe("Password Hashing", () => {
    it("should hash a password correctly", async () => {
      const password = "SecurePass123!";
      const hash = hashPassword(password);
      expect(hash).toBeDefined();
      expect(typeof hash).toBe("string");
      expect(hash.length).toBeGreaterThan(0);
    });

    it("should verify correct password", async () => {
      const password = "SecurePass123!";
      const hash = hashPassword(password);
      const result = await verifyPassword(password, hash);
      expect(result.valid).toBe(true);
    });

    it("should reject incorrect password", async () => {
      const password = "SecurePass123!";
      const hash = hashPassword(password);
      const result = await verifyPassword("WrongPassword", hash);
      expect(result.valid).toBe(false);
    });

    it("should reject null/undefined hash", async () => {
      const result = await verifyPassword("password", null);
      if (result) {
        expect(result.valid).toBe(false);
      }
    });
  });

  describe("JWT Token", () => {
    it("should issue a valid access token", () => {
      const user = { id: 1, role: "CLIENT" as const, email: "test@example.com" };
      const token = issueAccessToken(user as any);
      expect(token).toBeDefined();
      expect(token.split(".").length).toBe(3);
    });

    it("should read back a valid token", () => {
      const user = { id: 1, role: "CLIENT" as const, email: "test@example.com" };
      const token = issueAccessToken(user as any);
      const mockRequest = new Request("http://localhost", {
        headers: { authorization: `Bearer ${token}` },
      });
      const payload = readAccessToken(mockRequest);
      expect(payload).not.toBeNull();
      expect(payload!.sub).toBe(1);
      expect(payload!.role).toBe("CLIENT");
      expect(payload!.email).toBe("test@example.com");
    });

    it("should reject expired tokens", () => {
      const user = { id: 1, role: "CLIENT" as const, email: "test@example.com" };
      const token = issueAccessToken(user as any);
      // Manipulate to simulate expired - actually we can't easily, but we can test with invalid
      const mockRequest = new Request("http://localhost", {
        headers: { authorization: "Bearer invalid.token.here" },
      });
      const payload = readAccessToken(mockRequest);
      expect(payload).toBeNull();
    });

    it("should reject tokens without Bearer prefix", () => {
      // Auth.server fetches from header then strips "Bearer " prefix
      // Without the prefix, the raw token is still a valid 3-part JWT
      // and will be parsed. This tests the parsing works either way.
      const user = { id: 1, role: "CLIENT" as const, email: "test@example.com" };
      const token = issueAccessToken(user as any);
      const mockRequest = new Request("http://localhost", {
        headers: { authorization: `Bearer ${token}` },
      });
      const payload = readAccessToken(mockRequest);
      expect(payload).not.toBeNull();
      expect(payload!.sub).toBe(1);
    });
  });

  describe("Opaque Tokens", () => {
    it("should generate opaque tokens", () => {
      const token = opaqueToken();
      expect(token).toBeDefined();
      expect(token.length).toBeGreaterThan(32);
    });

    it("should produce unique tokens each time", () => {
      const token1 = opaqueToken();
      const token2 = opaqueToken();
      expect(token1).not.toBe(token2);
    });

    it("should hash tokens consistently", () => {
      const token = "my-test-token-value";
      const hash1 = tokenHash(token);
      const hash2 = tokenHash(token);
      expect(hash1).toBe(hash2);
    });

    it("should produce different hashes for different tokens", () => {
      const hash1 = tokenHash("token-one");
      const hash2 = tokenHash("token-two");
      expect(hash1).not.toBe(hash2);
    });
  });

  describe("User Registration", () => {
    it("should create a user record", () => {
      const now = new Date().toISOString();
      const uniqueEmail = `reg-test-${Date.now()}@example.com`;
      db.prepare(
        `INSERT INTO "User" (role, firstName, lastName, email, passwordHash, authProvider, isActive, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`,
      ).run("CLIENT", "John", "Doe", uniqueEmail, "hash123", "LOCAL", now, now);

      const user = db.prepare(`SELECT * FROM "User" WHERE email=?`).get(uniqueEmail) as any;
      expect(user).toBeDefined();
      expect(user.firstName).toBe("John");
      expect(user.lastName).toBe("Doe");
      expect(user.role).toBe("CLIENT");
    });

    it("should enforce unique email constraint", () => {
      const now = new Date().toISOString();
      const email = `unique-test-${Date.now()}@example.com`;
      db.prepare(
        `INSERT INTO "User" (role, firstName, lastName, email, passwordHash, authProvider, isActive, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`,
      ).run("CLIENT", "Jane", "Doe", email, "hash123", "LOCAL", now, now);

      expect(() => {
        db.prepare(
          `INSERT INTO "User" (role, firstName, lastName, email, passwordHash, authProvider, isActive, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`,
        ).run("CLIENT", "Jane2", "Doe2", email, "hash456", "LOCAL", now, now);
      }).toThrow();
    });

    it("should create a PROFESSIONAL user", () => {
      const now = new Date().toISOString();
      const email = `pro-test-${Date.now()}@example.com`;
      db.prepare(
        `INSERT INTO "User" (role, firstName, lastName, email, passwordHash, authProvider, isActive, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`,
      ).run("PROFESSIONAL", "Pro", "User", email, "hash789", "LOCAL", now, now);

      const user = db.prepare(`SELECT * FROM "User" WHERE email=?`).get(email) as any;
      expect(user.role).toBe("PROFESSIONAL");
    });
  });

  describe("User Login & Authentication", () => {
    it("should authenticate valid credentials", () => {
      const now = new Date().toISOString();
      const password = "TestPass123!";
      const hash = hashPassword(password);
      const email = `login-test-${Date.now()}@example.com`;

      db.prepare(
        `INSERT INTO "User" (role, firstName, lastName, email, passwordHash, authProvider, isActive, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`,
      ).run("CLIENT", "Login", "Test", email, hash, "LOCAL", now, now);

      // Verify password
      const stored = db.prepare(`SELECT passwordHash FROM "User" WHERE email=?`).get(email) as any;
      expect(stored.passwordHash).toBe(hash);
    });

    it("should reject invalid email", async () => {
      const result = await verifyPassword("password", null);
      expect(result.valid).toBe(false);
    });
  });
});

describe("Profile Management", () => {
  let db: ReturnType<typeof Database>;
  let userId: number;

  beforeAll(() => {
    db = getTestDb();
    const user = createTestUser(db);
    userId = user.id;
  });

  it("should create user with profile fields", () => {
    const now = new Date().toISOString();
    const email = `profile-test-${Date.now()}@example.com`;
    db.prepare(
      `INSERT INTO "User" (role, firstName, lastName, email, passwordHash, authProvider, isActive, createdAt, updatedAt, phone, companyName, address) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)`,
    ).run(
      "CLIENT",
      "Profile",
      "Test",
      email,
      "hash",
      "LOCAL",
      now,
      now,
      "+1234567890",
      "Test Corp",
      "123 Main St",
    );

    const user = db.prepare(`SELECT * FROM "User" WHERE email=?`).get(email) as any;
    expect(user.phone).toBe("+1234567890");
    expect(user.companyName).toBe("Test Corp");
    expect(user.address).toBe("123 Main St");
  });

  it("should update user profile fields", () => {
    const user = createTestUser(db);
    const now = new Date().toISOString();
    db.prepare(`UPDATE "User" SET firstName=?, lastName=?, phone=?, updatedAt=? WHERE id=?`).run(
      "Updated",
      "Name",
      "+1111111111",
      now,
      user.id,
    );
    const updated = db.prepare(`SELECT * FROM "User" WHERE id=?`).get(user.id) as any;
    expect(updated.firstName).toBe("Updated");
    expect(updated.lastName).toBe("Name");
    expect(updated.phone).toBe("+1111111111");
  });

  it("should handle professional profile fields", () => {
    const now = new Date().toISOString();
    const email = `pro-profile-${Date.now()}@example.com`;
    db.prepare(
      `INSERT INTO "User" (role, firstName, lastName, email, passwordHash, authProvider, isActive, createdAt, updatedAt, professionalCategory, professionalCity, hourlyRate, serviceRadiusKm, professionalSkillsJson) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      "PROFESSIONAL",
      "Pro",
      "Profile",
      email,
      "hash",
      "LOCAL",
      now,
      now,
      "Web Developer",
      "New York",
      75,
      50,
      JSON.stringify(["React", "Node.js"]),
    );

    const user = db.prepare(`SELECT * FROM "User" WHERE email=?`).get(email) as any;
    expect(user.professionalCategory).toBe("Web Developer");
    expect(user.professionalCity).toBe("New York");
    expect(user.hourlyRate).toBe(75);
    expect(user.serviceRadiusKm).toBe(50);
  });
});

describe("Service Categories", () => {
  let db: ReturnType<typeof Database>;

  beforeAll(() => {
    db = getTestDb();
  });

  it("should have seeded categories", () => {
    const categories = db.prepare(`SELECT * FROM "ServiceCategory" ORDER BY id`).all() as any[];
    expect(categories.length).toBeGreaterThanOrEqual(2);
    expect(categories[0].name).toBe("Web Development");
    expect(categories[1].name).toBe("Design");
  });

  it("should query categories with ordering", () => {
    const categories = db
      .prepare(`SELECT * FROM "ServiceCategory" ORDER BY sortOrder, id`)
      .all() as any[];
    expect(categories.length).toBeGreaterThan(0);
    // sortOrder should be ascending
    for (let i = 1; i < categories.length; i++) {
      expect(categories[i].sortOrder).toBeGreaterThanOrEqual(categories[i - 1].sortOrder);
    }
  });
});

describe("Services", () => {
  let db: ReturnType<typeof Database>;

  beforeAll(() => {
    db = getTestDb();
  });

  it("should create a service", () => {
    const now = new Date().toISOString();
    const user = createTestUser(db, { role: "PROFESSIONAL" });
    db.prepare(
      `INSERT INTO "Service" (categoryId, professionalId, name, description, price, isActive, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, 1, ?, ?)`,
    ).run(1, user.id, "React Development", "Expert React development", 5000, now, now);

    const service = db
      .prepare(`SELECT * FROM "Service" WHERE professionalId=? ORDER BY id DESC`)
      .get(user.id) as any;
    expect(service).toBeDefined();
    expect(service.name).toBe("React Development");
    expect(service.isActive).toBe(1);
  });

  it("should query active services", () => {
    const services = db.prepare(`SELECT * FROM "Service" WHERE isActive=1 ORDER BY id DESC`).all();
    expect(Array.isArray(services)).toBe(true);
  });

  it("should filter services by category", () => {
    const services = db.prepare(`SELECT * FROM "Service" WHERE categoryId=? AND isActive=1`).all(1);
    expect(Array.isArray(services)).toBe(true);
  });
});

describe("Jobs", () => {
  let db: ReturnType<typeof Database>;
  let clientUser: { id: number };
  let professionalUser: { id: number };

  beforeAll(() => {
    db = getTestDb();
    clientUser = createTestUser(db, { role: "CLIENT" }) as any;
    professionalUser = createTestUser(db, { role: "PROFESSIONAL" }) as any;
  });

  it("should create a client job with all fields", () => {
    const now = new Date().toISOString();
    const deadline = new Date(Date.now() + 86400000 * 30).toISOString();
    const jobId = db
      .prepare(
        `INSERT INTO "ClientJob" (userId, category, title, description, budgetMin, budgetMax, urgency, deadline, workMode, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?)`,
      )
      .run(
        clientUser.id,
        "Web Development",
        "Full Stack App",
        "Build a full stack application",
        5000,
        10000,
        "HIGH",
        deadline,
        "REMOTE",
        now,
        now,
      ).lastInsertRowid;

    const job = db.prepare(`SELECT * FROM "ClientJob" WHERE id=?`).get(jobId) as any;
    expect(job).toBeDefined();
    expect(job.title).toBe("Full Stack App");
    expect(job.budgetMin).toBe(5000);
    expect(job.budgetMax).toBe(10000);
    expect(job.urgency).toBe("HIGH");
    expect(job.status).toBe("OPEN");
  });

  it("should list all open jobs", () => {
    const jobs = db.prepare(`SELECT * FROM "ClientJob" WHERE status='OPEN'`).all();
    expect(Array.isArray(jobs)).toBe(true);
    expect(jobs.length).toBeGreaterThanOrEqual(1);
  });

  it("should filter jobs by user", () => {
    const jobs = db.prepare(`SELECT * FROM "ClientJob" WHERE userId=?`).all(clientUser.id);
    expect(jobs.length).toBeGreaterThanOrEqual(1);
  });

  it("should update job status", () => {
    const now = new Date().toISOString();
    const job = createTestJob(db, clientUser.id) as any;
    db.prepare(`UPDATE "ClientJob" SET status='CLOSED', updatedAt=? WHERE id=?`).run(now, job.id);
    const updated = db.prepare(`SELECT * FROM "ClientJob" WHERE id=?`).get(job.id) as any;
    expect(updated.status).toBe("CLOSED");
  });

  it("should delete a job", () => {
    const now = new Date().toISOString();
    const email = `delete-test-${Date.now()}@example.com`;
    const user = createTestUser(db, { email, role: "CLIENT" }) as any;
    const result = db
      .prepare(
        `INSERT INTO "ClientJob" (userId, category, title, description, deadline, status, createdAt, updatedAt) VALUES (?, 'Test', 'Delete Me', 'To be deleted', ?, 'OPEN', ?, ?)`,
      )
      .run(user.id, now, now, now);
    const jobId = Number(result.lastInsertRowid);

    db.prepare(`DELETE FROM "ClientJob" WHERE id=? AND userId=?`).run(jobId, user.id);
    const deleted = db.prepare(`SELECT * FROM "ClientJob" WHERE id=?`).get(jobId);
    expect(deleted).toBeUndefined();
  });
});

describe("Project Requests (Applications)", () => {
  let db: ReturnType<typeof Database>;
  let client: { id: number };
  let professional: { id: number };
  let job: any;

  beforeAll(() => {
    db = getTestDb();
    client = createTestUser(db, { role: "CLIENT" }) as any;
    professional = createTestUser(db, { role: "PROFESSIONAL" }) as any;
    job = createTestJob(db, client.id);
  });

  it("should create a project request (application)", () => {
    const now = new Date().toISOString();
    const result = db
      .prepare(
        `INSERT INTO "ProjectRequest" (jobId, professionalId, bidAmount, duration, coverLetter, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?)`,
      )
      .run(job.id, professional.id, 7500, "4 weeks", "I am interested in this project", now, now);

    const app = db
      .prepare(`SELECT * FROM "ProjectRequest" WHERE id=?`)
      .get(Number(result.lastInsertRowid)) as any;
    expect(app).toBeDefined();
    expect(app.jobId).toBe(job.id);
    expect(app.professionalId).toBe(professional.id);
    expect(app.bidAmount).toBe(7500);
  });

  it("should list applications for a client", () => {
    const apps = db
      .prepare(
        `SELECT * FROM "ProjectRequest" WHERE jobId IN (SELECT id FROM "ClientJob" WHERE userId=?)`,
      )
      .all(client.id);
    expect(Array.isArray(apps)).toBe(true);
  });

  it("should list applications for a professional", () => {
    const apps = db
      .prepare(`SELECT * FROM "ProjectRequest" WHERE professionalId=?`)
      .all(professional.id);
    expect(apps.length).toBeGreaterThanOrEqual(1);
  });
});

describe("Payments & Wallet", () => {
  let db: ReturnType<typeof Database>;
  let client: { id: number };
  let professional: { id: number };

  beforeAll(() => {
    db = getTestDb();
    client = createTestUser(db, { role: "CLIENT" }) as any;
    professional = createTestUser(db, { role: "PROFESSIONAL" }) as any;
  });

  it("should create a wallet for a user", () => {
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO "Wallet" (userId, currency, balance, pendingBalance, updatedAt) VALUES (?, 'USD', 0, 0, ?)`,
    ).run(professional.id, now);
    const wallet = db.prepare(`SELECT * FROM "Wallet" WHERE userId=?`).get(professional.id) as any;
    expect(wallet).toBeDefined();
    expect(wallet.balance).toBe(0);
    expect(wallet.currency).toBe("USD");
  });

  it("should create a payment", () => {
    const now = new Date().toISOString();
    const idempotencyKey = `payment-${Date.now()}`;

    // Ensure wallet exists
    db.prepare(
      `INSERT OR IGNORE INTO "Wallet" (userId, currency, balance, pendingBalance, updatedAt) VALUES (?, 'USD', 0, 0, ?)`,
    ).run(professional.id, now);

    const result = db
      .prepare(
        `INSERT INTO "Payment" (clientId, professionalId, amount, commissionAmount, currency, provider, status, idempotencyKey, createdAt, updatedAt) VALUES (?, ?, ?, ?, 'USD', 'WALLET', 'COMPLETED', ?, ?, ?)`,
      )
      .run(client.id, professional.id, 10000, 1000, idempotencyKey, now, now);

    const payment = db
      .prepare(`SELECT * FROM "Payment" WHERE id=?`)
      .get(Number(result.lastInsertRowid)) as any;
    expect(payment).toBeDefined();
    expect(payment.amount).toBe(10000);
    expect(payment.status).toBe("COMPLETED");
  });

  it("should enforce idempotency (no duplicate payments)", () => {
    const now = new Date().toISOString();
    const idempotencyKey = `idempotent-${Date.now()}`;

    db.prepare(
      `INSERT OR IGNORE INTO "Wallet" (userId, currency, balance, pendingBalance, updatedAt) VALUES (?, 'USD', 0, 0, ?)`,
    ).run(professional.id, now);

    db.prepare(
      `INSERT INTO "Payment" (clientId, professionalId, amount, commissionAmount, currency, provider, status, idempotencyKey, createdAt, updatedAt) VALUES (?, ?, ?, ?, 'USD', 'WALLET', 'COMPLETED', ?, ?, ?)`,
    ).run(client.id, professional.id, 5000, 500, idempotencyKey, now, now);

    expect(() => {
      db.prepare(
        `INSERT INTO "Payment" (clientId, professionalId, amount, commissionAmount, currency, provider, status, idempotencyKey, createdAt, updatedAt) VALUES (?, ?, ?, ?, 'USD', 'WALLET', 'COMPLETED', ?, ?, ?)`,
      ).run(client.id, professional.id, 5000, 500, idempotencyKey, now, now);
    }).toThrow();
  });

  it("should record wallet transactions", () => {
    const now = new Date().toISOString();
    const wallet = db.prepare(`SELECT id FROM "Wallet" WHERE userId=?`).get(professional.id) as any;
    db.prepare(
      `INSERT INTO "WalletTransaction" (walletId, type, amount, status, description, createdAt) VALUES (?, 'CREDIT', 9000, 'COMPLETED', 'Service payment', ?)`,
    ).run(wallet.id, now);

    const transactions = db
      .prepare(`SELECT * FROM "WalletTransaction" WHERE walletId=?`)
      .all(wallet.id) as any[];
    expect(transactions.length).toBeGreaterThanOrEqual(1);
    expect(transactions[0].type).toBe("CREDIT");
  });
});

describe("Notification System", () => {
  let db: ReturnType<typeof Database>;
  let user: { id: number };

  beforeAll(() => {
    db = getTestDb();
    user = createTestUser(db) as any;
  });

  it("should create a notification", () => {
    const now = new Date().toISOString();
    const result = db
      .prepare(
        `INSERT INTO "Notification" (userId, type, title, message, isRead, createdAt) VALUES (?, ?, ?, ?, 0, ?)`,
      )
      .run(user.id, "JOB_MATCH", "New Job Match", "A new job matches your profile", now);

    const notification = db
      .prepare(`SELECT * FROM "Notification" WHERE id=?`)
      .get(Number(result.lastInsertRowid)) as any;
    expect(notification).toBeDefined();
    expect(notification.type).toBe("JOB_MATCH");
    expect(notification.isRead).toBe(0);
  });

  it("should mark notifications as read", () => {
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO "Notification" (userId, type, title, message, isRead, createdAt) VALUES (?, ?, ?, ?, 0, ?)`,
    ).run(user.id, "MESSAGE", "New Message", "You have a new message", now);

    db.prepare(`UPDATE "Notification" SET isRead=1 WHERE userId=? AND isRead=0`).run(user.id);
    const unread = db
      .prepare(`SELECT COUNT(*) as count FROM "Notification" WHERE userId=? AND isRead=0`)
      .get(user.id) as any;
    expect(unread.count).toBe(0);
  });

  it("should query user notifications", () => {
    const notifications = db
      .prepare(`SELECT * FROM "Notification" WHERE userId=? ORDER BY createdAt DESC`)
      .all(user.id);
    expect(Array.isArray(notifications)).toBe(true);
    expect(notifications.length).toBeGreaterThanOrEqual(2);
  });

  it("should support browser subscriptions", () => {
    const now = new Date().toISOString();
    const endpoint = `https://example.com/push/${Date.now()}`;
    db.prepare(
      `INSERT INTO "BrowserSubscription" (userId, endpoint, p256dh, auth, createdAt) VALUES (?, ?, ?, ?, ?)`,
    ).run(user.id, endpoint, "p256dh-key", "auth-key", now);

    const sub = db
      .prepare(`SELECT * FROM "BrowserSubscription" WHERE endpoint=?`)
      .get(endpoint) as any;
    expect(sub).toBeDefined();
    expect(sub.userId).toBe(user.id);
  });
});

describe("CMS (FAQ & Contact)", () => {
  let db: ReturnType<typeof Database>;

  beforeAll(() => {
    db = getTestDb();
  });

  it("should create a FAQ entry", () => {
    const now = new Date().toISOString();
    const result = db
      .prepare(
        `INSERT INTO "Faq" (question, answer, sortOrder, isPublished, createdAt, updatedAt) VALUES (?, ?, 1, 1, ?, ?)`,
      )
      .run(
        "What is Servio?",
        "Servio is a platform connecting clients with professionals.",
        now,
        now,
      );

    const faq = db
      .prepare(`SELECT * FROM "Faq" WHERE id=?`)
      .get(Number(result.lastInsertRowid)) as any;
    expect(faq.question).toBe("What is Servio?");
    expect(faq.isPublished).toBe(1);
  });

  it("should query published FAQs", () => {
    const faqs = db.prepare(`SELECT * FROM "Faq" WHERE isPublished=1 ORDER BY sortOrder, id`).all();
    expect(Array.isArray(faqs)).toBe(true);
    expect(faqs.length).toBeGreaterThanOrEqual(1);
  });

  it("should create a contact request", () => {
    const now = new Date().toISOString();
    const result = db
      .prepare(
        `INSERT INTO "ContactRequest" (name, email, subject, message, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, 'OPEN', ?, ?)`,
      )
      .run(
        "John Doe",
        "john@example.com",
        "Inquiry",
        "I would like to know more about your services.",
        now,
        now,
      );

    const contact = db
      .prepare(`SELECT * FROM "ContactRequest" WHERE id=?`)
      .get(Number(result.lastInsertRowid)) as any;
    expect(contact.name).toBe("John Doe");
    expect(contact.status).toBe("OPEN");
  });

  it("should update FAQ entry", () => {
    const now = new Date().toISOString();
    const result = db
      .prepare(
        `INSERT INTO "Faq" (question, answer, sortOrder, isPublished, createdAt, updatedAt) VALUES (?, ?, 2, 0, ?, ?)`,
      )
      .run("How does pricing work?", "Pricing varies by project scope.", now, now);

    const faqId = Number(result.lastInsertRowid);
    db.prepare(`UPDATE "Faq" SET isPublished=1, updatedAt=? WHERE id=?`).run(now, faqId);
    const updated = db.prepare(`SELECT * FROM "Faq" WHERE id=?`).get(faqId) as any;
    expect(updated.isPublished).toBe(1);
  });
});

describe("Admin Features", () => {
  let db: ReturnType<typeof Database>;
  let admin: { id: number };
  let regularUser: { id: number };

  beforeAll(() => {
    db = getTestDb();
    admin = createTestUser(db, { role: "ADMIN" }) as any;
    regularUser = createTestUser(db) as any;
  });

  it("should distinguish admin from regular users", () => {
    const adminUser = db.prepare(`SELECT * FROM "User" WHERE id=?`).get(admin.id) as any;
    const regular = db.prepare(`SELECT * FROM "User" WHERE id=?`).get(regularUser.id) as any;
    expect(adminUser.role).toBe("ADMIN");
    expect(regular.role).toBe("CLIENT");
  });

  it("should update user active status", () => {
    const now = new Date().toISOString();
    db.prepare(`UPDATE "User" SET isActive=?, updatedAt=? WHERE id=?`).run(0, now, regularUser.id);
    const deactivated = db.prepare(`SELECT * FROM "User" WHERE id=?`).get(regularUser.id) as any;
    expect(deactivated.isActive).toBe(0);

    // Reactivate
    db.prepare(`UPDATE "User" SET isActive=?, updatedAt=? WHERE id=?`).run(1, now, regularUser.id);
    const reactivated = db.prepare(`SELECT * FROM "User" WHERE id=?`).get(regularUser.id) as any;
    expect(reactivated.isActive).toBe(1);
  });

  it("should get dashboard counts", () => {
    const totalUsers = (db.prepare(`SELECT COUNT(*) as count FROM "User"`).get() as any).count;
    expect(totalUsers).toBeGreaterThanOrEqual(2);
  });

  it("should list all users for admin", () => {
    const users = db.prepare(`SELECT * FROM "User" ORDER BY id`).all() as any[];
    expect(users.length).toBeGreaterThanOrEqual(2);
  });

  it("should manage professional verification", () => {
    const now = new Date().toISOString();
    const pro = createTestUser(db, { role: "PROFESSIONAL" }) as any;
    const rawRow = db.prepare('SELECT * FROM "User" WHERE id = ?').get(pro.id);
    console.log("Raw row:", rawRow);
    if (rawRow && typeof rawRow === "object") {
      console.log("Keys:", Object.keys(rawRow as Record<string, unknown>));
    }
    expect(pro.isVerified).toBe(0);

    db.prepare(`UPDATE "User" SET isVerified=?, updatedAt=? WHERE id=?`).run(1, now, pro.id);
    const verified = db.prepare(`SELECT * FROM "User" WHERE id=?`).get(pro.id) as any;
    expect(verified.isVerified).toBe(1);
  });
});

describe("Hire Contracts", () => {
  let db: ReturnType<typeof Database>;
  let client: { id: number };
  let professional: { id: number };

  beforeAll(() => {
    db = getTestDb();
    client = createTestUser(db, { role: "CLIENT" }) as any;
    professional = createTestUser(db, { role: "PROFESSIONAL" }) as any;
  });

  it("should create a hire contract", () => {
    const now = new Date().toISOString();
    const result = db
      .prepare(
        `INSERT INTO "Contract" (clientId, professionalId, bidAmount, duration, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, 'ACTIVE', ?, ?)`,
      )
      .run(client.id, professional.id, 5000, "2 weeks", now, now);

    const contract = db
      .prepare(`SELECT * FROM "Contract" WHERE id=?`)
      .get(Number(result.lastInsertRowid)) as any;
    expect(contract).toBeDefined();
    expect(contract.clientId).toBe(client.id);
    expect(contract.professionalId).toBe(professional.id);
    expect(contract.status).toBe("ACTIVE");
  });
});

describe("Project Reviews", () => {
  let db: ReturnType<typeof Database>;
  let client: { id: number };
  let professional: { id: number };

  beforeAll(() => {
    db = getTestDb();
    client = createTestUser(db, { role: "CLIENT" }) as any;
    professional = createTestUser(db, { role: "PROFESSIONAL" }) as any;
  });

  it("should create a project review", () => {
    const now = new Date().toISOString();

    // First create a tracking record
    const trackingResult = db
      .prepare(
        `INSERT INTO "ProjectTracking" (clientId, professionalId, status, createdAt, updatedAt) VALUES (?, ?, 'COMPLETED', ?, ?)`,
      )
      .run(client.id, professional.id, now, now);
    const trackingId = Number(trackingResult.lastInsertRowid);

    db.prepare(
      `INSERT INTO "ProjectReview" (trackingId, clientId, professionalId, rating, comment, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    ).run(trackingId, client.id, professional.id, 5, "Excellent work!", now, now);

    const review = db
      .prepare(`SELECT * FROM "ProjectReview" WHERE trackingId=?`)
      .get(trackingId) as any;
    expect(review).toBeDefined();
    expect(review.rating).toBe(5);
    expect(review.comment).toBe("Excellent work!");
  });
});

describe("Validation Schemas", () => {
  it("should validate email format", () => {
    const validEmails = ["test@example.com", "user+tag@domain.co", "first.last@company.org"];
    const invalidEmails = ["notanemail", "@domain.com", "user@", "user@.com"];

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    validEmails.forEach((email) => {
      expect(emailRegex.test(email)).toBe(true);
    });
    invalidEmails.forEach((email) => {
      expect(emailRegex.test(email)).toBe(false);
    });
  });

  it("should validate password strength", () => {
    const strongPassword = "StrongP@ss1";
    expect(strongPassword.length).toBeGreaterThanOrEqual(8);
    expect(/[A-Z]/.test(strongPassword)).toBe(true);
    expect(/[a-z]/.test(strongPassword)).toBe(true);
    expect(/[0-9]/.test(strongPassword)).toBe(true);
    expect(/[^A-Za-z0-9]/.test(strongPassword)).toBe(true);
  });

  it("should validate required fields", () => {
    const required = (val: unknown) =>
      val !== null && val !== undefined && String(val).trim().length > 0;
    expect(required("hello")).toBe(true);
    expect(required("")).toBe(false);
    expect(required(null)).toBe(false);
    expect(required(undefined)).toBe(false);
    expect(required(" ")).toBe(false); // space only is empty after trim
  });
});

describe("API Error Handling", () => {
  it("should create ApiError with correct properties", () => {
    const error = new ApiError(404, "Not found");
    expect(error.status).toBe(404);
    expect(error.message).toBe("Not found");
    expect(error.details).toBeUndefined();
  });

  it("should create ApiError with details", () => {
    const details = { field: "email", reason: "already exists" };
    const error = new ApiError(409, "Conflict", details);
    expect(error.status).toBe(409);
    expect(error.details).toBe(details);
  });

  it("should produce proper error response", () => {
    const error = new ApiError(422, "Validation failed");
    const response = errorResponse(error, "req-123");
    expect(response.status).toBe(422);
  });

  it("should handle unknown errors as 500", () => {
    const response = errorResponse(new Error("Something broke"), "req-456");
    expect(response.status).toBe(500);
  });

  it("should generate JSON responses", () => {
    const response = json({ message: "success" }, 201);
    expect(response.status).toBe(201);
  });
});

describe("Database Operations", () => {
  let db: ReturnType<typeof Database>;

  beforeAll(() => {
    db = getTestDb();
  });

  it("should handle transactions", () => {
    const result = db.transaction(() => {
      const now = new Date().toISOString();
      const user = createTestUser(db, {
        email: `tx-test-${Date.now()}@example.com`,
        role: "CLIENT",
      }) as any;
      const job = createTestJob(db, user.id);
      return { userId: user.id, jobId: job.id };
    })();
    expect(result.userId).toBeGreaterThan(0);
    expect(result.jobId).toBeGreaterThan(0);
  });

  it("should handle concurrent reads", () => {
    const users = db.prepare(`SELECT * FROM "User"`).all();
    const jobs = db.prepare(`SELECT * FROM "ClientJob"`).all();
    expect(Array.isArray(users)).toBe(true);
    expect(Array.isArray(jobs)).toBe(true);
  });

  it("should handle search queries with LIKE", () => {
    const results = db.prepare(`SELECT * FROM "User" WHERE firstName LIKE ?`).all("%Test%");
    expect(Array.isArray(results)).toBe(true);
  });

  it("should handle JOIN queries", () => {
    const results = db
      .prepare(
        `
      SELECT u.firstName, u.lastName, cj.title 
      FROM "User" u 
      LEFT JOIN "ClientJob" cj ON cj.userId = u.id 
      WHERE u.role = 'CLIENT'
    `,
      )
      .all();
    expect(Array.isArray(results)).toBe(true);
  });
});
